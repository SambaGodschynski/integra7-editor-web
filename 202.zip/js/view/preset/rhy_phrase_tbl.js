//
// 	rhy_phrase_tbl.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//
globals.parameter.phrase.rhyPhraseTbl = [
	"No Assign",
	"Standard 1",
	"Standard 2",
	"Room 1",
	"Room 2",
	"Power 1",
	"Power 2",
	"Electric 1",
	"Electric 2",
	"Analog 1",
	"Analog 2",
	"Jazz 1",
	"Jazz 2",
	"Brush 1",
	"Brush 2",
	"Orchestra 1",
	"Orchestra 2",
	"SFX 1",
	"SFX 2"
];
