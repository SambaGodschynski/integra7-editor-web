//
//  PCM_DRUM_KIT-SRX_08.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//
globals.parameter.presetTone.pcmDrumKitSrx08 = [
	[	0,	92,	15,	0,	CATEG_DRM,	"Techno Kit 2"	],
	[	1,	92,	15,	1,	CATEG_DRM,	"HipHop Kit"	],
	[	2,	92,	15,	2,	CATEG_DRM,	"House Kit 2"	],
	[	3,	92,	15,	3,	CATEG_DRM,	"Trance Kit"	],
	[	4,	92,	15,	4,	CATEG_DRM,	"DnB Kit"	],
	[	5,	92,	15,	5,	CATEG_DRM,	"BrekBeatsKit"	],
	[	6,	92,	15,	6,	CATEG_DRM,	"R&B Kit 3"	],
	[	7,	92,	15,	7,	CATEG_DRM,	"TR-909 Kit"	],
	[	8,	92,	15,	8,	CATEG_DRM,	"TR-808 Kit"	],
	[	9,	92,	15,	9,	CATEG_DRM,	"TR606/707Kit"	],
	[	10,	92,	15,	10,	CATEG_DRM,	"Kick Menu"	],
	[	11,	92,	15,	11,	CATEG_DRM,	"Snare1 Menu"	],
	[	12,	92,	15,	12,	CATEG_DRM,	"Snr2&RimMenu"	],
	[	13,	92,	15,	13,	CATEG_DRM,	"HHat&TomMenu"	],
	[	14,	92,	15,	14,	CATEG_DRM,	"Cym&Clp Menu"	],
	[	15,	92,	15,	15,	CATEG_DRM,	"Hit&StabMenu"	],
	[	16,	92,	15,	16,	CATEG_DRM,	"Perc. Menu"	],
	[	17,	92,	15,	17,	CATEG_DRM,	"Vox Menu"	],
	[	18,	92,	15,	18,	CATEG_DRM,	"FX Menu"	],
	[	19,	92,	15,	19,	CATEG_DRM,	"Beat Menu 1"	],
	[	20,	92,	15,	20,	CATEG_DRM,	"Beat Menu 2"	]
];