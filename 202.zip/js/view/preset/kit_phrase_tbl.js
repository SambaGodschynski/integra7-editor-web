//
//  kit_phrase_tbl.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//
globals.parameter.phrase.kitPhraseTbl = [                    
	"No Assign",
	"Standard 1",
	"Jazz 1",
	"Brush 1",
	"Orchestra 1",
	"Standard 2",
	"Standard 3",
	"Std 3 w/Perc",
	"Rock 1",
	"Rock 1w/Perc",
	"Rock 2",
	"Rock 2w/Perc",
	"Jazz 2",
	"Jazz 2w/Perc",
	"Brush 2",
	"Brush2w/Perc",
	"Orchestra 2"
];



