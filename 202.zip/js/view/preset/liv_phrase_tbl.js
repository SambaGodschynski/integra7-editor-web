//
//  liv_phrase_tbl.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//
globals.parameter.phrase.livPhraseTbl = [
	"No Assign",
	"Quick Bells",
	"Arp Approach",
	"Stack Split",
	"Floating",
	"J-Clube",
	"Club Duo",
	"Gi-Groove",
	"Bouncing Drops",
	"ElectricBird Pad",
	"Arp Bells",
	"Tranceship",
	"Synthology",
	"Just Add Rhythm",
	"Arpeg-Gi-o",
	"Breathalizer",
	"Generator",
	"Trance Files",
	"Contemporary",
	"Analogroove",
	"Synthpop Split",
	"Vintage Motion",
	"Dancing Waves",
	"Arp Approach 02",
	"Quick Bells 02",
];
