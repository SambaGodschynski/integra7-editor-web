//
//  SN_ACOUSTIC-EXP_SN_05.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//
globals.parameter.presetTone.snAcousticExpSn05 = [
	[	0,	89,	100,	0,	CATEG_SBRS ,	"Flugel Horn     "	],
	[	1,	89,	100,	1,	CATEG_SBRS ,	"Trumpet 2       "	],
	[	2,	89,	100,	2,	CATEG_SBRS ,	"Mariachi Tp     "	],
	[	3,	89,	100,	3,	CATEG_SBRS ,	"Classic Tp      "	],
	[	4,	89,	100,	4,	CATEG_SBRS ,	"CupMute Tp      "	],
	[	5,	89,	100,	5,	CATEG_SBRS ,	"StraightMtTp    "	],
	[	6,	89,	100,	6,	CATEG_SBRS ,	"FrenchHorn2     "	],
	[	7,	89,	100,	7,	CATEG_SBRS ,	"FHorn2 Stc      "	],
	[	8,	89,	100,	8,	CATEG_SBRS ,	"Trombone 2      "	],
	[	9,	89,	100,	9,	CATEG_SBRS ,	"Bass Tb         "	],
	[	10,	89,	100,	10,	CATEG_SBRS ,	"Tuba            "	],
	[	11,	89,	100,	11,	CATEG_SBRS ,	"TubaStaccato    "	]
];
