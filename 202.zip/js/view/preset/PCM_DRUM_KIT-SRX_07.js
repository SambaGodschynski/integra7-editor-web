//
//  PCM_DRUM_KIT-SRX_07.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//
globals.parameter.presetTone.pcmDrumKitSrx07 = [
	[	0,	92,	11,	0,	CATEG_DRM,	"Ring Kit"	],
	[	1,	92,	11,	1,	CATEG_DRM,	"Slam Kit"	],
	[	2,	92,	11,	2,	CATEG_DRM,	"Verb Kit"	],
	[	3,	92,	11,	3,	CATEG_DRM,	"Slap Kit"	],
	[	4,	92,	11,	4,	CATEG_DRM,	"RockOn Kit"	],
	[	5,	92,	11,	5,	CATEG_DRM,	"DryFat Kit"	],
	[	6,	92,	11,	6,	CATEG_DRM,	"LiteFunk Kit"	],
	[	7,	92,	11,	7,	CATEG_DRM,	"Warm Kit"	],
	[	8,	92,	11,	8,	CATEG_DRM,	"HiTune Kit"	],
	[	9,	92,	11,	9,	CATEG_DRM,	"AnalogRhyKit"	],
	[	10,	92,	11,	10,	CATEG_DRM,	"AllRhy Menu"	]
];
