//
//  SN_ACOUSTIC-EXP_SN_04.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//
globals.parameter.presetTone.snAcousticExpSn04 = [
	                         
	[	0,	89,	99,	0,	CATEG_AGT ,	"12StringsGtr "	],
	[	1,	89,	99,	1,	CATEG_AGT ,	"Deturned12Gt "	],
	[	2,	89,	99,	2,	CATEG_AGT ,	"Ukulele      "	],
	[	3,	89,	99,	3,	CATEG_AGT ,	"UkuleleStrum "	],
	[	4,	89,	99,	4,	CATEG_AGT ,	"FingSteelGtr "	],
	[	5,	89,	99,	5,	CATEG_AGT ,	"FingStlStrum "	],
	[	6,	89,	99,	6,	CATEG_AGT ,	"SoftPckStlGt "	],
	[	7,	89,	99,	7,	CATEG_AGT ,	"SftPkStlStrm "	],
	[	8,	89,	99,	8,	CATEG_AGT ,	"NylonGt2     "	],
	[	9,	89,	99,	9,	CATEG_AGT ,	"NylonGt2Strm "	],
	[	10,	89,	99,	10,	CATEG_AGT ,	"MandolinGt   "	],
	[	11,	89,	99,	11,	CATEG_AGT ,	"MandolinStum "	]
];
