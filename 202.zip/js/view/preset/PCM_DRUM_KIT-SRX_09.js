//
//  PCM_DRUM_KIT-SRX_09.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//
globals.parameter.presetTone.pcmDrumKitSrx09 = [
	[	0,	92,	19,	0,	CATEG_DRM,	"LatinDrmKit"	],
	[	1,	92,	19,	1,	CATEG_DRM,	"AsiaDrm Kit"	],
	[	2,	92,	19,	2,	CATEG_DRM,	"IndiaDrmKit"	],
	[	3,	92,	19,	3,	CATEG_DRM,	"MidEastDrKit"	],
	[	4,	92,	19,	4,	CATEG_DRM,	"World Phrase"	],
	[	5,	92,	19,	5,	CATEG_DRM,	"Gtr Phrase"	],
	[	6,	92,	19,	6,	CATEG_DRM,	"Latin Menu1"	],
	[	7,	92,	19,	7,	CATEG_DRM,	"Latin Menu2"	],
	[	8,	92,	19,	8,	CATEG_DRM,	"Latin Menu3"	],
	[	9,	92,	19,	9,	CATEG_DRM,	"Asia Menu"	],
	[	10,	92,	19,	10,	CATEG_DRM,	"India Menu"	],
	[	11,	92,	19,	11,	CATEG_DRM,	"MidEast Menu"	]
];
