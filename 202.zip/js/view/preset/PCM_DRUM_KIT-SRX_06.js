//
//  PCM_DRUM_KIT-SRX_06.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//
globals.parameter.presetTone.pcmDrumKitSrx06 = [
	[	0,	92,	7,	0,	CATEG_DRM,	"Orch. Kit 1"	],
	[	1,	92,	7,	1,	CATEG_DRM,	"Orch. Kit 2"	],
	[	2,	92,	7,	2,	CATEG_DRM,	"Melo OrchKit"	],
	[	3,	92,	7,	3,	CATEG_DRM,	"GM AssignKit"	],
	[	4,	92,	7,	4,	CATEG_DRM,	"All Orch Kit"	]
];
