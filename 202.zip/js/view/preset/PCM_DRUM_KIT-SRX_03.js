//
//  PCM_DRUM_KIT-SRX_03.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//
globals.parameter.presetTone.pcmDrumKitSrx03 = [
	[	0,	92,	2,	0,	CATEG_DRM,	"WideRock KIT"	],
	[	1,	92,	2,	1,	CATEG_DRM,	"WideJazz KIT"	],
	[	2,	92,	2,	2,	CATEG_DRM,	"TightRoomKIT"	],
	[	3,	92,	2,	3,	CATEG_DRM,	"3rdBalladKIT"	],
	[	4,	92,	2,	4,	CATEG_DRM,	"Studio 1 KIT"	],
	[	5,	92,	2,	5,	CATEG_DRM,	"Studio 2 KIT"	],
	[	6,	92,	2,	6,	CATEG_DRM,	"Studio 3 KIT"	],
	[	7,	92,	2,	7,	CATEG_DRM,	"Studio 4 KIT"	],
	[	8,	92,	2,	8,	CATEG_DRM,	"HipHop KIT"	],
	[	9,	92,	2,	9,	CATEG_DRM,	"Dyn.Perc KIT"	],
	[	10,	92,	2,	10,	CATEG_DRM,	"Drums MENU"	],
	[	11,	92,	2,	11,	CATEG_DRM,	"Perc. MENU"	]
];
