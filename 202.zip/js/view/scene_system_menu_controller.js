//
//  scene_system_menu_controller.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//

//////////////////////////////////////////////////////////////////////

window.parent.globals.controller.sytem_menu = new window.parent.globals.controller.base();		

