//
//  scene_motionalsurround_menu_controller.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//

//////////////////////////////////////////////////////////////////////

window.parent.globals.controller.motionalsurround_menu = new window.parent.globals.controller.base();		

