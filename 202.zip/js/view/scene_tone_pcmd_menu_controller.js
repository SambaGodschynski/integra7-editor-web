//
//  scene_tone_pcmd_menu_controller.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//

//////////////////////////////////////////////////////////////////////

window.parent.globals.controller.tone_pcmd_menu = new window.parent.globals.controller.base();		

