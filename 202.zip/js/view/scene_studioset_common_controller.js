//
//  scene_studioset_common_controller.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//

//////////////////////////////////////////////////////////////////////

window.parent.globals.controller.studioset_common = new window.parent.globals.controller.base();		

