//
//  scene_tone_snd_controller.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//

//////////////////////////////////////////////////////////////////////

window.parent.globals.controller.tone_snd = new window.parent.globals.controller.base_tone();		

