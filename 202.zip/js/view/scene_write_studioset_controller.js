//
//  scene_write_studioset_controller.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//

//////////////////////////////////////////////////////////////////////

window.parent.globals.controller.write_studioset = new window.parent.globals.controller.base();		



