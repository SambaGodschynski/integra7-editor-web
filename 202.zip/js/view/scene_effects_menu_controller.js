//
//  scene_effects_menu_controller.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//

//////////////////////////////////////////////////////////////////////

window.parent.lobals.controller.effects_menu = new window.parent.globals.controller.base();		

