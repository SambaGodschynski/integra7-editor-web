//
//  scene_utility_controller.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//

//////////////////////////////////////////////////////////////////////

window.parent.globals.controller.utility = new window.parent.globals.controller.base_studioset_view();		

