//
//  scene_motionalsurround_controller.js
//
//  Copyright 2014 Roland Corporation. All rights reserved.
//

//////////////////////////////////////////////////////////////////////

window.parent.globals.controller.motionalsurround = new window.parent.globals.controller.base_tone();		

/*

window.parent.globals.controller.motionalsurround.getVal = function (id, v) {
	var ret;
	
	if (id.indexOf("_FPART1") !== -1) {
		ret = window.parent.globals.controller.base_tone.prototype.getVal(id);	
	} else {
		ret = window.parent.globals.controller.base.prototype.getVal(id);
	}

	return ret;
};

window.parent.globals.controller.motionalsurround.get = function (id, v) {
	var ret;
		
	if (id.indexOf("_FPART1") !== -1) {
		ret = window.parent.globals.controller.base_tone.prototype.get(id);	
	} else {
		ret = window.parent.globals.controller.base.prototype.get(id);
	}

	return ret;
};

window.parent.globals.controller.motionalsurround.put = function (id, v) {
	
	if (id.indexOf("_FPART1") !== -1) {
		window.parent.globals.controller.base_tone.prototype.put(id, v);
	} else {
		window.parent.globals.controller.base.prototype.put(id, v);
	}


};

*/

