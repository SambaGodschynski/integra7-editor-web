//
//	vst copyright.js
//
//	Copyright 2014 Roland Corporation. All rights reserved.
//


window.globals.vst_copyright = "VST PlugIn Technology by Steinberg.<br>"
+"VST PlugIn Interface Technology by Steinberg Media Technologies GmbH.<br>"