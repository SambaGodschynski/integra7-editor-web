//
//	vst copyright.js
//
//	Copyright 2014 Roland Corporation. All rights reserved.
//


window.globals.other_copyright = "jQuery:Copyright 2005, 2012 jQuery Foundation, Inc. and other contributors Released under the MIT license<br>"
+"jQuery UI:Copyright 2013 jQuery Foundation and other contributors; Licensed MIT<br>";